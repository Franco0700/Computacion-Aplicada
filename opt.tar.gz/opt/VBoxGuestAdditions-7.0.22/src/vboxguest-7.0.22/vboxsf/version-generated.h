#ifndef ___version_generated_h___
#define ___version_generated_h___

#define VBOX_VERSION_MAJOR 7
#define VBOX_VERSION_MINOR 0
#define VBOX_VERSION_BUILD 22
#define VBOX_VERSION_STRING_RAW "7.0.22"
#define VBOX_VERSION_STRING "7.0.22"
#define VBOX_API_VERSION_STRING "7_0"

#define VBOX_BUILD_SERVER_BUILD 1

#endif
