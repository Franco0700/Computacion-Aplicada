#!/bin/bash


show_help() {
    echo "Usage: $0 [origin] [destiny]"
    echo "Options:"
    echo "  -h            Show Help"
    echo "Example: $0 /var/logs /backup_dir"
    exit 0
}

if [[ "$1" == "-h" ]]; then
    show_help
fi

if [[ $# -ne 2 ]]; then
    echo "Error: origin and destiny required"
    show_help
fi

origin=$1
destiny=$2

if [[ ! -d "$origin" ]]; then
    echo "Error: $origin directory missing or not mounted"
    exit 1
fi

if [[ ! -d "$destiny" ]]; then
    echo "Error: $destiny directory missing or not mounted"
    exit 1
fi


date=$(date +%Y%m%d)


filename=$("$origin")_bkp_$date.tar.gz


tar -czf "$destiny/$filename" "$origin"


if [[ $? -eq 0 ]]; then
    echo "$origin backuped sucessfully in $destiny/$filename"
else
    echo "Error when backuping $origin"
    exit 1
fi
